
var count = 0

function likeButton(element) {
    const count = document.querySelector(element);
    count.innerHTML++;
}





