
var count = 0

function likeButton() {
    document.querySelector("span").innerText++;
    count++;
}