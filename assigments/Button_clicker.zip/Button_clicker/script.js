function loginLogout(element) {
    element.innerText = "Logout";
}

function removeDef(element) {
    element.remove();
}